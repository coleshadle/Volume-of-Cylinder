# circleCalc
Code calculates area and circumference of a circle
